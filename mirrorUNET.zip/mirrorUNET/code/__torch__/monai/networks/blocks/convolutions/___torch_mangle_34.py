class ResidualUnit(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  spatial_dims : int
  in_channels : int
  out_channels : int
  conv : __torch__.torch.nn.modules.container.___torch_mangle_32.Sequential
  residual : __torch__.torch.nn.modules.conv.___torch_mangle_33.Conv3d
  def forward(self: __torch__.monai.networks.blocks.convolutions.___torch_mangle_34.ResidualUnit,
    x: Tensor) -> Tensor:
    residual = self.residual
    res = (residual).forward(x, )
    conv = self.conv
    cx = (conv).forward(x, )
    return torch.add(cx, res)
