class ADN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  N : __torch__.torch.nn.modules.batchnorm.___torch_mangle_19.BatchNorm3d
  D : __torch__.torch.nn.modules.dropout.Dropout
  A : __torch__.torch.nn.modules.activation.PReLU
  def forward(self: __torch__.monai.networks.blocks.acti_norm.___torch_mangle_20.ADN,
    input: Tensor) -> Tensor:
    N = self.N
    D = self.D
    A = self.A
    input0 = (N).forward(input, )
    input1 = (D).forward(input0, )
    return (A).forward(input1, )
  def __len__(self: __torch__.monai.networks.blocks.acti_norm.___torch_mangle_20.ADN) -> int:
    return 3
