class Mirror_UNet(Module):
  __parameters__ = ["learnable_th", ]
  __buffers__ = []
  learnable_th : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  dimensions : int
  in_channels : int
  out_channels : int
  channels : Tuple[int, int, int, int, int]
  strides : Tuple[int, int, int, int]
  kernel_size : int
  up_kernel_size : int
  num_res_units : int
  act : str
  norm : str
  dropout : float
  bias : bool
  adn_ordering : str
  task : str
  gpu : int
  depth : int
  level : int
  sliding_window : bool
  separate_outputs : bool
  mirror_th : float
  learnable_th_arg : bool
  device : Device
  common_down_indices : List[int]
  common_up_indices : List[int]
  down_1 : __torch__.torch.nn.modules.container.ModuleList
  up_1 : __torch__.torch.nn.modules.container.ModuleList
  common_downs : __torch__.torch.nn.modules.container.ModuleList
  common_ups : __torch__.torch.nn.modules.container.ModuleList
  down_2 : __torch__.torch.nn.modules.container.ModuleList
  up_2 : __torch__.torch.nn.modules.container.ModuleList
  dec : __torch__.torch.nn.modules.container.ModuleList
  down_1_1 : __torch__.monai.networks.blocks.convolutions.ResidualUnit
  down_2_1 : __torch__.monai.networks.blocks.convolutions.ResidualUnit
  down_1_2 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_9.ResidualUnit
  down_2_2 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_9.ResidualUnit
  down_1_3 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_17.ResidualUnit
  down_2_3 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_17.ResidualUnit
  down_1_4 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_25.ResidualUnit
  down_2_4 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_25.ResidualUnit
  common_bottom : __torch__.monai.networks.blocks.convolutions.___torch_mangle_34.ResidualUnit
  up_1_1 : __torch__.torch.nn.modules.container.___torch_mangle_38.Sequential
  up_2_1 : __torch__.torch.nn.modules.container.___torch_mangle_38.Sequential
  up_1_2 : __torch__.torch.nn.modules.container.___torch_mangle_43.Sequential
  up_2_2 : __torch__.torch.nn.modules.container.___torch_mangle_43.Sequential
  up_1_3 : __torch__.torch.nn.modules.container.___torch_mangle_48.Sequential
  up_2_3 : __torch__.torch.nn.modules.container.___torch_mangle_48.Sequential
  up_1_4 : __torch__.torch.nn.modules.container.___torch_mangle_57.Sequential
  up_2_4 : __torch__.torch.nn.modules.container.___torch_mangle_66.Sequential
  def forward(self: __torch__.models.mirror_UNet_iterative.Mirror_UNet,
    x: Tensor) -> Tensor:
    x_1 = torch.unsqueeze(torch.select(torch.slice(x), 1, 0), 1)
    down_1_1 = self.down_1_1
    x_11 = (down_1_1).forward(x_1, )
    down_1_2 = self.down_1_2
    x_12 = (down_1_2).forward(x_11, )
    down_1_3 = self.down_1_3
    x_13 = (down_1_3).forward(x_12, )
    down_1_4 = self.down_1_4
    x_14 = (down_1_4).forward(x_13, )
    common_bottom = self.common_bottom
    x_15 = (common_bottom).forward(x_14, )
    up_1_1 = self.up_1_1
    x_10 = (up_1_1).forward(torch.cat([x_14, x_15], 1), )
    up_1_2 = self.up_1_2
    x_16 = (up_1_2).forward(torch.cat([x_13, x_10], 1), )
    up_1_3 = self.up_1_3
    x_17 = (up_1_3).forward(torch.cat([x_12, x_16], 1), )
    up_1_4 = self.up_1_4
    x_18 = (up_1_4).forward(torch.cat([x_11, x_17], 1), )
    print(torch.size(x_18))
    x_2 = torch.unsqueeze(torch.select(torch.slice(x), 1, 1), 1)
    down_2_1 = self.down_2_1
    x_119 = (down_2_1).forward(x_2, )
    down_2_2 = self.down_2_2
    x_128 = (down_2_2).forward(x_119, )
    down_2_3 = self.down_2_3
    x_137 = (down_2_3).forward(x_128, )
    down_2_4 = self.down_2_4
    x_144 = (down_2_4).forward(x_137, )
    common_bottom0 = self.common_bottom
    x_154 = (common_bottom0).forward(x_144, )
    up_2_1 = self.up_2_1
    x_20 = (up_2_1).forward(torch.cat([x_144, x_154], 1), )
    up_2_2 = self.up_2_2
    x_21 = (up_2_2).forward(torch.cat([x_137, x_20], 1), )
    up_2_3 = self.up_2_3
    x_22 = (up_2_3).forward(torch.cat([x_128, x_21], 1), )
    up_2_4 = self.up_2_4
    x_23 = (up_2_4).forward(torch.cat([x_119, x_22], 1), )
    return torch.cat([x_18, x_23], 1)
